'use client'
import { useState } from "react";

export default function Page() {
  const [projectName, setProjectName] = useState("");
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!projectName || !file) {
      setStatus("⚠️ Lengkapi nama & file (.zip) sebelum deploy!");
      return;
    }
    setStatus("🚀 Mengunggah...");
    const fd = new FormData();
    fd.append("projectName", projectName);
    fd.append("file", file);

    try {
      const res = await fetch("/api/proxy", {
        method: "POST",
        body: fd
      });
      const data = await res.json();
      if (res.ok) {
        setStatus("✅ Deploy sukses! URL: " + (data.url || data.message || "—"));
        if (data.url) window.open(data.url, "_blank");
      } else {
        setStatus("❌ Gagal: " + (data.error || data.message || "Server error"));
      }
    } catch (err) {
      setStatus("❌ Kesalahan jaringan: " + err.message);
    }
  }

  return (
    <main style={{minHeight: '100vh', display:'flex', alignItems:'center', justifyContent:'center', background: 'radial-gradient(circle at 10% 10%, #2b0036 0%, #05021a 40%, #001a33 100%)', color:'#fff', padding:'24px'}}>
      <div style={{maxWidth:420, width:'100%', background:'rgba(0,0,0,0.6)', border:'1px solid rgba(0,255,255,0.15)', padding:32, borderRadius:16, boxShadow:'0 0 30px rgba(0,255,255,0.08)'}}>
        <h1 style={{fontFamily:'Orbitron, sans-serif', fontSize:28, color:'#0ff', textShadow:'0 0 12px #0ff'}}>YannDev Deploy</h1>
        <p style={{color:'#cbd5e1'}}>🚀 Upload ZIP project dan deploy otomatis</p>

        <form onSubmit={onSubmit} style={{marginTop:16}}>
          <label style={{display:'block', color:'#9aa9b8', marginBottom:6}}>Nama Website</label>
          <input required value={projectName} onChange={(e)=>setProjectName(e.target.value)} placeholder="contoh: my-project" style={{width:'100%', padding:10, borderRadius:8, background:'rgba(0,0,0,0.4)', border:'1px solid rgba(0,255,255,0.08)', color:'#fff'}} />

          <label style={{display:'block', color:'#9aa9b8', marginBottom:6, marginTop:12}}>Upload File (.zip)</label>
          <input required type="file" accept=".zip" onChange={(e)=>setFile(e.target.files[0])} style={{width:'100%', color:'#fff'}} />

          <button type="submit" style={{marginTop:16, width:'100%', padding:12, borderRadius:8, background:'rgba(0,255,255,0.12)', border:'1px solid #0ff', color:'#0ff', cursor:'pointer', fontWeight:700}}>⚡ Deploy Sekarang</button>
        </form>

        {status && <p style={{marginTop:12, color:'#ffb6c1'}}>{status}</p>}

        <footer style={{marginTop:18, fontSize:12, color:'#9aa9b8'}}>Made with 💙 by <span style={{color:'#ff7bdc'}}>YannDev</span></footer>
      </div>
    </main>
  )
}
