YannDev Deploy - Ready-to-upload Next.js project
================================================

This project is a minimal Next.js app (JavaScript) with a cyberpunk-themed UI called "YannDev Deploy".
It includes a serverless API route that proxies uploaded ZIP files to an external API using an API key.

IMPORTANT:
- Before deploying to Vercel, set environment variables in the Vercel dashboard:
  - EXTERNAL_API_ENDPOINT (default: https://api.example.com/deploy)
  - EXTERNAL_API_KEY (your provided key)

Files:
- app/page.jsx        -> Frontend UI (form to input project name and upload a ZIP)
- pages/api/proxy.js  -> Serverless endpoint that forwards the uploaded file to EXTERNAL_API_ENDPOINT using EXTERNAL_API_KEY
- .env.example        -> Example environment file (DO NOT commit your real secret to public repos)

How to deploy:
1. Upload this ZIP to Vercel via https://vercel.com/new (Import Project -> Upload)
2. In Project Settings -> Environment Variables, add:
   - EXTERNAL_API_ENDPOINT = https://api.example.com/deploy
   - EXTERNAL_API_KEY = uwCGtFS7xjGsnnnmfKt3FIpa
3. Deploy. The site will be live on a vercel.app domain.

Security note:
- The provided EXTERNAL_API_KEY is included in .env.example only for convenience. Avoid committing secrets to public repositories.
