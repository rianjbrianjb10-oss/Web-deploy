import formidable from "formidable";
import fs from "fs";
import fetch from "node-fetch";

export const config = {
  api: {
    bodyParser: false
  }
};

const EXTERNAL_ENDPOINT = process.env.EXTERNAL_API_ENDPOINT || "https://api.example.com/deploy";
const EXTERNAL_KEY = process.env.EXTERNAL_API_KEY || "";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const form = new formidable.IncomingForm();
  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ error: "Form parse failed" });

    try {
      const file = files.file;
      if (!file) return res.status(400).json({ error: "No file uploaded" });

      const fileData = fs.readFileSync(file.filepath);

      // Forward the file to the external API
      const forwardRes = await fetch(EXTERNAL_ENDPOINT, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${EXTERNAL_KEY}`,
          // Let node-fetch set Content-Type for multipart when using body as Buffer is not multipart;
          // If external API expects raw binary body, we send it directly.
        },
        body: fileData
      });

      const text = await forwardRes.text();
      let json;
      try { json = JSON.parse(text); } catch(e) { json = { message: text }; }

      if (forwardRes.ok) {
        return res.status(200).json(json);
      } else {
        return res.status(forwardRes.status).json({ error: json.error || json.message || "Forward failed", details: json });
      }
    } catch (e) {
      return res.status(500).json({ error: "Internal server error", details: e.message });
    }
  });
}
